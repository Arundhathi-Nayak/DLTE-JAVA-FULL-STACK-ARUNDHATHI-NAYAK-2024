package org.fileRepository;

import org.example.Employee;

import java.util.ResourceBundle;

public class ExceptionEmployee extends RuntimeException {
    public ExceptionEmployee(){
        super(ResourceBundle.getBundle("application").getString("employee.Exception"));
    }
    public ExceptionEmployee(String additionalInfo){
        super(ResourceBundle.getBundle("application").getString("employee.Exception")+" "+additionalInfo);
    }
}
